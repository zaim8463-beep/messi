package com.example.touchassist

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.UUID
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max

// ───────────────────────────── الزر العائم ─────────────────────────────

class AssistButton(ctx: Context) : View(ctx) {

    interface Listener {
        fun onSingle()
        fun onDouble()
        fun onTriple()
        fun onQuad()
        fun onLong()
        fun onFlick(dir: String)
        fun onPress()
        fun onDrag(dx: Float, dy: Float)
        fun onDragEnd()
    }

    var listener: Listener? = null
    var hasDouble = false
    var hasTriple = false
    var hasQuad = false
    var hasFlick = false
    var longPressMs = 500L
    var doubleTapMs = 300L

    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private val h = Handler(Looper.getMainLooper())
    private var downX = 0f
    private var downY = 0f
    private var downT = 0L
    private var moved = false
    private var longFired = false
    private var dragging = false
    private var flickCandidate = false
    private var tapCount = 0
    private var pendingTap: Runnable? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    private val longRun = Runnable {
        if (!moved) {
            longFired = true
            pendingTap?.let { h.removeCallbacks(it) }
            pendingTap = null
            tapCount = 0
            listener?.onLong()
        }
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val cx = w / 2f
        val cy = height / 2f
        // زي أيقونة iOS 13: دايرة غامقة نص شفافة، حلقة رمادية سميكة، ودايرة بيضا في النص
        p.style = Paint.Style.FILL
        p.color = Color.argb(238, 36, 28, 42)
        c.drawCircle(cx, cy, w * 0.5f, p)
        p.color = Color.argb(240, 172, 166, 180)
        c.drawCircle(cx, cy, w * 0.375f, p)
        p.color = Color.argb(255, 255, 255, 255)
        c.drawCircle(cx, cy, w * 0.245f, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = w * 0.012f
        p.color = Color.argb(160, 120, 112, 128)
        c.drawCircle(cx, cy, w * 0.245f, p)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX
                downY = e.rawY
                downT = e.eventTime
                moved = false
                longFired = false
                dragging = false
                flickCandidate = false
                listener?.onPress()
                h.postDelayed(longRun, longPressMs)
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.rawX - downX
                val dy = e.rawY - downY
                if (!moved && hypot(dx.toDouble(), dy.toDouble()) > slop) {
                    moved = true
                    h.removeCallbacks(longRun)
                    flickCandidate = hasFlick && !longFired
                }
                if (moved) {
                    if (flickCandidate && e.eventTime - downT < 220L) {
                        // ممكن يكون سحب سريع (Flick): منحرّكش الزر لسه
                    } else {
                        flickCandidate = false
                        dragging = true
                        listener?.onDrag(dx, dy)
                    }
                }
            }
            MotionEvent.ACTION_UP -> {
                h.removeCallbacks(longRun)
                if (moved) {
                    if (dragging) {
                        listener?.onDragEnd()
                    } else if (flickCandidate) {
                        val dx = e.rawX - downX
                        val dy = e.rawY - downY
                        val dir = if (abs(dx) > abs(dy)) {
                            if (dx > 0) "right" else "left"
                        } else {
                            if (dy > 0) "down" else "up"
                        }
                        listener?.onFlick(dir)
                    }
                } else if (!longFired) {
                    handleTap()
                }
            }
            MotionEvent.ACTION_CANCEL -> {
                h.removeCallbacks(longRun)
                if (dragging) listener?.onDragEnd()
            }
        }
        return true
    }

    private fun fireTaps(n: Int) {
        when (n) {
            1 -> listener?.onSingle()
            2 -> listener?.onDouble()
            3 -> listener?.onTriple()
            else -> listener?.onQuad()
        }
    }

    private fun handleTap() {
        val maxTaps = if (hasQuad) 4 else if (hasTriple) 3 else if (hasDouble) 2 else 1
        tapCount++
        pendingTap?.let { h.removeCallbacks(it) }
        pendingTap = null
        if (tapCount >= maxTaps) {
            val n = tapCount
            tapCount = 0
            fireTaps(n)
        } else {
            val r = Runnable {
                val n = tapCount
                tapCount = 0
                pendingTap = null
                fireTaps(n)
            }
            pendingTap = r
            h.postDelayed(r, doubleTapMs)
        }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        h.removeCallbacksAndMessages(null)
    }
}

// ───────────────────────────── شاشة تسجيل الإيماءة ─────────────────────────────

class RecorderView(
    ctx: Context,
    private val sw: Int,
    private val sh: Int,
    private val onSave: (Gesture) -> Unit,
    private val onCancel: () -> Unit,
    private val light: Boolean = false
) : FrameLayout(ctx) {

    private class Live(val startOffset: Long) {
        val pts = ArrayList<Pt>()
    }

    private val strokes = ArrayList<Live>()
    private val active = HashMap<Int, Live>()
    private var recStart = -1L
    private var playT = -1f
    private var anim: ValueAnimator? = null
    private val surface = Surface(ctx)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    init {
        setBackgroundColor(if (light) Color.parseColor("#FAFAFC") else Color.argb(45, 0, 0, 0))
        addView(surface, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val bar = LinearLayout(ctx)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.isClickable = true
        val bg = GradientDrawable()
        bg.cornerRadius = dp(14).toFloat()
        bg.setColor(Color.parseColor(if (light) "#F2F2F7" else "#EE1C1C1E"))
        if (light) bg.setStroke(dp(1), Color.parseColor("#D1D1D6"))
        bar.background = bg
        bar.setPadding(dp(6), dp(2), dp(6), dp(2))
        val col = if (light) Color.parseColor("#007AFF") else Color.WHITE
        bar.addView(btn("إلغاء", col, false) { cancel() })
        bar.addView(btn("مسح", col, false) { clear() })
        bar.addView(btn("تشغيل", col, false) { preview() })
        bar.addView(btn("حفظ", col, true) { save() })
        val blp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        if (light) {
            blp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            blp.bottomMargin = dp(28)
        } else {
            blp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            blp.topMargin = dp(28)
        }
        addView(bar, blp)
    }

    private fun btn(text: String, color: Int, bold: Boolean, onClick: () -> Unit): TextView {
        val t = TextView(context)
        t.text = text
        t.setTextColor(color)
        t.textSize = 15f
        if (bold) t.setTypeface(t.typeface, android.graphics.Typeface.BOLD)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(14), dp(9), dp(14), dp(9))
        t.setOnClickListener { onClick() }
        return t
    }

    private fun clear() {
        anim?.cancel()
        strokes.clear()
        active.clear()
        recStart = -1L
        playT = -1f
        surface.invalidate()
    }

    private fun cancel() {
        anim?.cancel()
        onCancel()
    }

    private fun preview() {
        if (strokes.isEmpty()) return
        anim?.cancel()
        val total = strokes.maxOf { it.startOffset + it.pts.last().t }.toFloat().coerceAtLeast(100f) + 300f
        val a = ValueAnimator.ofFloat(0f, total)
        a.duration = total.toLong()
        a.interpolator = LinearInterpolator()
        a.addUpdateListener {
            playT = it.animatedValue as Float
            surface.invalidate()
        }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                playT = -1f
                anim = null
                surface.invalidate()
            }
        })
        anim = a
        a.start()
    }

    private fun save() {
        if (strokes.isEmpty()) {
            Toast.makeText(context, "اعمل لمسة أو سحبة الأول", Toast.LENGTH_SHORT).show()
            return
        }
        anim?.cancel()
        val list = ArrayList<Stroke>()
        for (s in strokes) list.add(Stroke(s.startOffset, normalize(s.pts)))
        onSave(Gesture(UUID.randomUUID().toString(), "", list, sw, sh))
    }

    /** تخفيف النقاط + تحويل اللمسة/الضغطة الثابتة لنقطتين (بداية ونهاية بنفس المكان). */
    private fun normalize(src: List<Pt>): List<Pt> {
        val first = src.first()
        val last = src.last()
        var travel = 0f
        for (i in 1 until src.size) travel += abs(src[i].x - src[i - 1].x) + abs(src[i].y - src[i - 1].y)
        if (travel < 8f) {
            return listOf(first, Pt(first.x, first.y, max(last.t, 40L)))
        }
        val out = ArrayList<Pt>()
        out.add(first)
        var kept = first
        for (i in 1 until src.size - 1) {
            val p = src[i]
            if (abs(p.x - kept.x) + abs(p.y - kept.y) >= 3f) {
                out.add(p)
                kept = p
            }
        }
        out.add(Pt(last.x, last.y, max(last.t, out.last().t + 1)))
        return out
    }

    private inner class Surface(c: Context) : View(c) {
        private val density = c.resources.displayMetrics.density
        private val pathPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = density * 22f
            color = Color.rgb(0, 145, 255)
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }
        private val grayPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = density * 22f
            color = Color.rgb(190, 182, 194)
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }
        private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = Color.rgb(0, 200, 245)
        }
        private val grayDot = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = Color.rgb(190, 182, 194)
        }
        private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = density * 15f
            textAlign = Paint.Align.CENTER
        }
        private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = Color.argb(230, 0, 122, 255)
        }
        private var lx = 0f
        private var ly = 0f

        override fun onTouchEvent(e: MotionEvent): Boolean {
            if (anim != null) return true
            val loc = IntArray(2)
            getLocationOnScreen(loc)
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                    if (strokes.size >= 300) return true
                    if (recStart < 0) recStart = e.eventTime
                    val i = e.actionIndex
                    val s = Live(max(0L, e.eventTime - recStart))
                    s.pts.add(Pt(e.getX(i) + loc[0], e.getY(i) + loc[1], 0L))
                    active[e.getPointerId(i)] = s
                    strokes.add(s)
                }
                MotionEvent.ACTION_MOVE -> {
                    for (i in 0 until e.pointerCount) {
                        val s = active[e.getPointerId(i)] ?: continue
                        for (hh in 0 until e.historySize) {
                            addPt(s, e.getHistoricalX(i, hh) + loc[0], e.getHistoricalY(i, hh) + loc[1], e.getHistoricalEventTime(hh))
                        }
                        addPt(s, e.getX(i) + loc[0], e.getY(i) + loc[1], e.eventTime)
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                    val i = e.actionIndex
                    val s = active.remove(e.getPointerId(i))
                    if (s != null) addPt(s, e.getX(i) + loc[0], e.getY(i) + loc[1], e.eventTime)
                }
                MotionEvent.ACTION_CANCEL -> active.clear()
            }
            invalidate()
            return true
        }

        private fun addPt(s: Live, x: Float, y: Float, time: Long) {
            val t = max(time - recStart - s.startOffset, s.pts.last().t)
            s.pts.add(Pt(x, y, t))
        }

        private fun pathUpTo(s: Live, limit: Long, loc: IntArray): Path? {
            val path = Path()
            var started = false
            for (p in s.pts) {
                if (p.t > limit) break
                val x = p.x - loc[0]
                val y = p.y - loc[1]
                if (!started) {
                    path.moveTo(x, y)
                    started = true
                } else {
                    path.lineTo(x, y)
                }
                lx = x
                ly = y
            }
            return if (started) path else null
        }

        override fun onDraw(c: Canvas) {
            val loc = IntArray(2)
            getLocationOnScreen(loc)
            if (strokes.isEmpty()) {
                if (light) {
                    textPaint.color = Color.parseColor("#8E8E93")
                    textPaint.clearShadowLayer()
                } else {
                    textPaint.color = Color.WHITE
                    textPaint.setShadowLayer(8f, 0f, 0f, Color.BLACK)
                }
                val cx = width / 2f
                val cy = height / 2f
                c.drawText("قم بالضغط أو السحب لإنشاء إيماء مخصص.", cx, cy - density * 22f, textPaint)
                c.drawText("سيتم الجمع بين سلسلة من الإيماءات", cx, cy + density * 4f, textPaint)
                c.drawText("في إيماء واحد متعدد اللمس.", cx, cy + density * 26f, textPaint)
            }
            for ((idx, s) in strokes.withIndex()) {
                // آخر خط بس أزرق، والخطوط اللي قبله بتتحوّل لرمادي فاتح (زي iOS)
                val old = idx != strokes.size - 1 && playT < 0f
                val full = pathUpTo(s, Long.MAX_VALUE, loc)
                if (full != null) {
                    c.drawPath(full, if (old) grayPaint else pathPaint)
                    if (playT < 0f) c.drawCircle(lx, ly, density * 13f, if (old) grayDot else dotPaint)
                }
                if (playT >= 0f) {
                    val limit = playT.toLong() - s.startOffset
                    if (limit >= 0) {
                        val part = pathUpTo(s, limit, loc)
                        if (part != null) {
                            c.drawPath(part, grayPaint)
                            c.drawCircle(lx, ly, density * 13f, grayDot)
                        }
                    }
                }
            }
            // شريط تقدّم التسجيل (زي iOS)
            val total = strokes.maxOfOrNull { it.startOffset + (it.pts.lastOrNull()?.t ?: 0L) } ?: 0L
            val frac = (total / 10000f).coerceIn(0f, 1f)
            c.drawRect(0f, height - 8f, width * frac, height.toFloat(), barPaint)
        }
    }
}

// ───────────────────────────── شاشة اختيار مكان التنفيذ (زي دواير iOS الزرقا) ─────────────────────────────

class PlaceView(
    ctx: Context,
    private val g: Gesture,
    private val sw: Int,
    private val sh: Int,
    private val onDone: (Float, Float) -> Unit,
    private val onCancel: () -> Unit
) : FrameLayout(ctx) {

    private val sx = 1f
    private val sy = 1f
    private var cx = 0f
    private var cy = 0f
    private var offX = 0f
    private var offY = 0f

    private val circle = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.argb(170, 10, 132, 255)
    }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 6f
        color = Color.argb(120, 10, 132, 255)
        strokeCap = Paint.Cap.ROUND
    }
    private val hint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 44f
        textAlign = Paint.Align.CENTER
        setShadowLayer(8f, 0f, 0f, Color.BLACK)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    init {
        setWillNotDraw(false)
        setBackgroundColor(Color.argb(60, 0, 0, 0))
        var sumX = 0f
        var sumY = 0f
        for (s in g.strokes) {
            sumX += s.points.first().x * sx
            sumY += s.points.first().y * sy
        }
        val n = max(1, g.strokes.size)
        cx = sumX / n
        cy = sumY / n
        offX = sw / 2f - cx
        offY = sh / 2f - cy

        val cancelBtn = TextView(ctx)
        cancelBtn.text = "✖ إلغاء"
        cancelBtn.setTextColor(Color.WHITE)
        cancelBtn.textSize = 14f
        cancelBtn.setPadding(dp(16), dp(8), dp(16), dp(8))
        val bg = GradientDrawable()
        bg.cornerRadius = dp(20).toFloat()
        bg.setColor(Color.parseColor("#EE1C1C1E"))
        cancelBtn.background = bg
        cancelBtn.setOnClickListener { onCancel() }
        val lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp.topMargin = dp(28)
        addView(cancelBtn, lp)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                offX = e.rawX - cx
                offY = e.rawY - cy
                invalidate()
            }
            MotionEvent.ACTION_UP -> onDone(offX, offY)
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val loc = IntArray(2)
        getLocationOnScreen(loc)
        c.drawText("اسحب الدواير للمكان اللي عايزه وارفع إصبعك", width / 2f, height * 0.18f, hint)
        for (s in g.strokes) {
            val path = Path()
            var first = true
            for (p in s.points) {
                val x = p.x * sx + offX - loc[0]
                val y = p.y * sy + offY - loc[1]
                if (first) {
                    path.moveTo(x, y)
                    first = false
                } else {
                    path.lineTo(x, y)
                }
            }
            c.drawPath(path, line)
            val f = s.points.first()
            c.drawCircle(f.x * sx + offX - loc[0], f.y * sy + offY - loc[1], 40f, circle)
        }
    }
}


// ───────────────────────────── الكورة الثابتة (Armed) ─────────────────────────────

/**
 * الكورة الواحدة الثابتة: مبتتحركش. لو ليها أوامر (ضغطة / ضغطتين / ضغطة مطولة / سحب) بتستقبل اللمس وتنفّذ الهدف اللي حدّدته،
 * ولو ملهاش أوامر النافذة بتبقى "شفافة للمس" واللمس بيعدّي للتطبيق اللي تحتها.
 */
class PinnedView(
    ctx: Context,
    private val centers: List<PointF>,
    private val hasDouble: Boolean,
    private val onTrigger: (String) -> Unit
) : View(ctx) {

    var longMs = 500L
    var doubleMs = 300L
    var swipeDist = 0f

    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private val h = Handler(Looper.getMainLooper())
    private val density = ctx.resources.displayMetrics.density
    private val radius = Store.ballDp(ctx) * density / 2f
    private var downX = 0f
    private var downY = 0f
    private var moved = false
    private var longFired = false
    private var pendingTap: Runnable? = null

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.argb(55, 255, 255, 255)
    }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = ctx.resources.displayMetrics.density * 3f
        color = Store.ballColor(ctx)
    }
    private val core = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Store.ballColor(ctx)
    }

    private val longRun = Runnable {
        if (!moved) {
            longFired = true
            pendingTap?.let { h.removeCallbacks(it) }
            pendingTap = null
            onTrigger("long")
        }
    }

    override fun onDraw(c: Canvas) {
        for (p in centers) {
            c.drawCircle(p.x, p.y, radius, fill)
            c.drawCircle(p.x, p.y, radius, ring)
            c.drawCircle(p.x, p.y, density * 4f, core)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX
                downY = e.rawY
                moved = false
                longFired = false
                h.postDelayed(longRun, longMs)
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.rawX - downX
                val dy = e.rawY - downY
                if (!moved && hypot(dx.toDouble(), dy.toDouble()) > slop) {
                    moved = true
                    h.removeCallbacks(longRun)
                }
            }
            MotionEvent.ACTION_UP -> {
                h.removeCallbacks(longRun)
                if (longFired) return true
                if (moved) {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (max(abs(dx), abs(dy)) >= slop * 2) {
                        swipeDist = max(abs(dx), abs(dy))
                        val dir = if (abs(dx) > abs(dy)) {
                            if (dx > 0) "right" else "left"
                        } else {
                            if (dy > 0) "down" else "up"
                        }
                        onTrigger(dir)
                    }
                } else {
                    handleTap()
                }
            }
            MotionEvent.ACTION_CANCEL -> h.removeCallbacks(longRun)
        }
        return true
    }

    private fun handleTap() {
        if (!hasDouble) {
            onTrigger("tap")
            return
        }
        val pending = pendingTap
        if (pending != null) {
            h.removeCallbacks(pending)
            pendingTap = null
            onTrigger("double")
        } else {
            val r = Runnable {
                pendingTap = null
                onTrigger("tap")
            }
            pendingTap = r
            h.postDelayed(r, doubleMs)
        }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        h.removeCallbacksAndMessages(null)
    }
}

// ───────────────────────────── مرحلة الكور الكتيرة: حرّكها، وبعدين اضغط عليها عشان تتحوّل لكورة واحدة ثابتة ─────────────────────────────

class BallPlaceView(
    ctx: Context,
    private val starts: List<PointF>,
    private val anchor: PointF,
    tx0: Float,
    ty0: Float,
    private val onDone: (Float, Float) -> Unit,
    private val onCancel: () -> Unit
) : FrameLayout(ctx) {

    private var tx = tx0
    private var ty = ty0
    private val density = ctx.resources.displayMetrics.density
    private val radius = Store.ballDp(ctx) * density / 2f
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private var downX = 0f
    private var downY = 0f
    private var moved = false
    private var downOnBall = false
    private var grabDx = 0f
    private var grabDy = 0f

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.argb(60, 255, 255, 255)
    }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = ctx.resources.displayMetrics.density * 3f
        color = Store.ballColor(ctx)
    }
    private val core = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Store.ballColor(ctx)
    }
    private val hint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = ctx.resources.displayMetrics.density * 14f
        textAlign = Paint.Align.CENTER
        setShadowLayer(8f, 0f, 0f, Color.BLACK)
    }

    private fun dp(v: Int) = (v * density).toInt()

    init {
        setWillNotDraw(false)
        setBackgroundColor(Color.argb(40, 0, 0, 0))
        val cancelBtn = TextView(ctx)
        cancelBtn.text = "إلغاء"
        cancelBtn.setTextColor(Color.WHITE)
        cancelBtn.textSize = 15f
        cancelBtn.setPadding(dp(18), dp(9), dp(18), dp(9))
        val bg = GradientDrawable()
        bg.cornerRadius = dp(18).toFloat()
        bg.setColor(Color.parseColor("#EE1C1C1E"))
        cancelBtn.background = bg
        cancelBtn.setOnClickListener { onCancel() }
        val lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp.topMargin = dp(28)
        addView(cancelBtn, lp)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX
                downY = e.rawY
                moved = false
                downOnBall = false
                for (p in starts) {
                    if (hypot((p.x + tx - e.rawX).toDouble(), (p.y + ty - e.rawY).toDouble()) <= radius * 1.25f) {
                        downOnBall = true
                    }
                }
                if (downOnBall) {
                    // مسكت الكور: السحب بيحرّكها من غير ما تقفز
                    grabDx = e.rawX - (anchor.x + tx)
                    grabDy = e.rawY - (anchor.y + ty)
                } else {
                    // لمست مكان تاني: الكور بتيجي عند إصبعك وتمشي معاه
                    tx = e.rawX - anchor.x
                    ty = e.rawY - anchor.y
                    grabDx = 0f
                    grabDy = 0f
                    moved = true
                }
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                if (!moved && hypot((e.rawX - downX).toDouble(), (e.rawY - downY).toDouble()) > slop) moved = true
                if (moved) {
                    tx = e.rawX - grabDx - anchor.x
                    ty = e.rawY - grabDy - anchor.y
                    invalidate()
                }
            }
            // ضغطة (من غير سحب) على الكور = تتحوّل لكورة واحدة ثابتة في المكان ده
            MotionEvent.ACTION_UP -> if (downOnBall && !moved) onDone(tx, ty)
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val loc = IntArray(2)
        getLocationOnScreen(loc)
        c.drawText("حرّك الكور للمكان المطلوب، ثم اضغط عليها لتثبيتها", width / 2f, height * 0.2f, hint)
        for (p in starts) {
            val x = p.x + tx - loc[0]
            val y = p.y + ty - loc[1]
            c.drawCircle(x, y, radius, fill)
            c.drawCircle(x, y, radius, ring)
            c.drawCircle(x, y, density * 4.5f, core)
        }
    }
}
